package com.example.gpttest;

import java.util.ArrayList;

public class PersonList {
    private static PersonList instance;
    private ArrayList<Person> personList;

    private PersonList() {
        personList = new ArrayList<>();
    }

    public static synchronized PersonList getInstance() {
        if (instance == null) {
            instance = new PersonList();
        }
        return instance;
    }

    public void addPerson(Person person) {
        personList.add(person);
    }

    public void updatePerson(int position, String name, String status) {
        Person person = personList.get(position);
        person.setName(name);
        person.setStatus(status);
    }

    public void removePerson(int position) {
        personList.remove(position);
    }

    public Person getPerson(int position) {
        return personList.get(position);
    }

    public ArrayList<Person> getPersonList() {
        return personList;
    }

    public void setPersonList(ArrayList<Person> personList) {
        this.personList = personList;
    }

    public int getSize() {
        return personList.size();
    }
}
