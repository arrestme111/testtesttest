import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gpttest.R;

public class InputActivity extends AppCompatActivity {
    private EditText nameEditText;
    private Spinner statusSpinner;
    private Button saveButton;
    private int personPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        // Get references to input widgets
        nameEditText = findViewById(R.id.nameEditText);
        statusSpinner = findViewById(R.id.statusSpinner);
        saveButton = findViewById(R.id.saveButton);

        // Set up the spinner with the list of status options
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.status_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(adapter);

        // Check if we're editing an existing person or adding a new one
        if (getIntent().hasExtra("position")) {
            // Editing an existing person, get the person's data and populate the input fields
            personPosition = getIntent().getIntExtra("position", -1);
            Person person = PersonList.getInstance().getPerson(personPosition);
            nameEditText.setText(person.getName());
            statusSpinner.setSelection(adapter.getPosition(person.getStatus()));
            saveButton.setText(R.string.update_button_text);
        } else {
            // Adding a new person, set default values for input fields
            saveButton.setText(R.string.add_button_text);
        }

        // Set up the button click listener
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameEditText.getText().toString();
                String status = statusSpinner.getSelectedItem().toString();

                if (name.isEmpty()) {
                    // Display an error message if the name is empty
                    Toast.makeText(InputActivity.this, R.string.name_error_message, Toast.LENGTH_SHORT).show();
                    return;
                }

                if (personPosition == -1) {
                    // Adding a new person, create a new Person object and add it to the list
                    PersonList.getInstance().addPerson(new Person(name, status));
                } else {
                    // Editing an existing person, update the existing Person object with the new data
                    PersonList.getInstance().updatePerson(personPosition, name, status);
                }

                // Finish the activity and return to the main activity
                finish();
            }
        });
    }
}



