import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gpttest.Person;
import com.example.gpttest.PersonList;
import com.example.gpttest.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private PersonAdapter adapter;
    private EditText nameEditText;
    private Spinner statusSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Person> personList = PersonList.getInstance().getPersonList();
        adapter = new PersonAdapter(this, personList);

        RecyclerView recyclerView = findViewById(R.id.personRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        nameEditText = findViewById(R.id.nameEditText);
        statusSpinner = findViewById(R.id.statusSpinner);

        // Set up the spinner with the list of status options
        ArrayAdapter<CharSequence> statusAdapter = ArrayAdapter.createFromResource(this, R.array.status_array, android.R.layout.simple_spinner_item);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(statusAdapter);
    }

    public void addPerson(View view) {
        String name = nameEditText.getText().toString();
        String status = statusSpinner.getSelectedItem().toString();

        if (name.isEmpty()) {
            // Display an error message if the name is empty
            Toast.makeText(this, R.string.name_error_message, Toast.LENGTH_SHORT).show();
            return;
        }

        PersonList.getInstance().addPerson(new Person(name, status));
        adapter.notifyDataSetChanged();

        nameEditText.setText("");
        statusSpinner.setSelection(0);
    }
}
