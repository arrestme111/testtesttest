package com.example.gpttest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class PersonAdapter extends ArrayAdapter<Person> {
    private ArrayList<Person> personList;

    public PersonAdapter(Context context, ArrayList<Person> personList) {
        super(context, 0, personList);
        this.personList = personList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        Person currentPerson = personList.get(position);

        TextView nameTextView = listItemView.findViewById(R.id.nameTextView);
        nameTextView.setText(currentPerson.getName());

        TextView statusTextView = listItemView.findViewById(R.id.statusTextView);
        statusTextView.setText(currentPerson.getStatus());

        Button presentButton = listItemView.findViewById(R.id.presentButton);
        presentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPerson.setStatus("Present");
                notifyDataSetChanged();
            }
        });

        Button ftrButton = listItemView.findViewById(R.id.ftrButton);
        ftrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPerson.setStatus("FTR");
                notifyDataSetChanged();
            }
        });

        return listItemView;
    }
}
